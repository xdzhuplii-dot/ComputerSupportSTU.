# Computer Support STU

Laboratory works for Computer Support course at STU.
